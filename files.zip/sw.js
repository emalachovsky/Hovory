const CACHE_NAME = 'hovory-v1';
const urlsToCache = [
  './',
  './index.html',
  './manifest.json'
];

// Install event
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('Opened cache');
      return cache.addAll(urlsToCache);
    })
  );
  self.skipWaiting();
});

// Fetch event
self.addEventListener('fetch', event => {
  // Skip cross-origin requests
  if(event.request.url.includes('sheets.googleapis.com')){
    event.respondWith(
      fetch(event.request).catch(() => {
        return new Response('Offline - nemožno načítať dáta z Google Sheets', {
          status: 503,
          statusText: 'Service Unavailable'
        });
      })
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then(response => {
      if(response){
        return response;
      }
      
      return fetch(event.request).then(response => {
        // Don't cache non-successful responses
        if(!response || response.status !== 200 || response.type === 'error'){
          return response;
        }
        
        // Clone the response
        const responseToCache = response.clone();
        caches.open(CACHE_NAME).then(cache => {
          cache.put(event.request, responseToCache);
        });
        
        return response;
      });
    }).catch(() => {
      // Fallback to cached version
      return caches.match(event.request);
    })
  );
});

// Activate event
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if(cacheName !== CACHE_NAME){
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  self.clients.claim();
});
